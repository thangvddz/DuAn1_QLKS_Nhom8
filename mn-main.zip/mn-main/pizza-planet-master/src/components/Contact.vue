<template>
    <div class="card">
    <div class="card-body">
        <h5 class="card-title">Contact Us</h5>
        <p class="card-text">
            <address>
                <strong>Pizza Planet</strong><br>
                Address line 1 <br>
                Address line 2 <br>
                Phone: 097 234 2078
            </address>
            <address>
                <strong>Email:</strong> <br>
                <p>contact@pizzaplanet.net</p>
            </address>
        </p>
    </div>
    </div>
</template>
