// export const getMenuItems = state => state.menuItems
// export const numberOfOrders = state => state.orders.length
// export const currentUser = state => state.currentUser